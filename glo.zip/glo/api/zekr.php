<?php
date_default_timezone_set('Asia/Tehran');
$day = date('D');
switch($day){
	case 'Sat':
	echo 'یا رب العالمین';
	break;
	case 'Sun':
	echo 'یا ذالجلال والاکرام';
	break;
	case 'Mon':
	echo 'یا قاضی الحاجات';
	break;
	case 'Tue':
	echo 'یا ارحم الراحمین';
	break;
	case 'Wed':
	echo 'یا حی یا قیوم';
	break;
	case 'Thu':
	echo 'لا اله الا الله الملک الحق المبین';
	break;
	case 'Fri':
	echo 'اللهم صل علی محمد و ال محمد';
	break;
	default:
	echo 'پیام روز';						
}
?>